// import './App.css';
import Header from "../src/component/Header/header";
import Home from "../src/Home/home";
import Footer from "../src/component/Footer/footer";
// import Home from "../src/component/Form/form";

function App() {
  return (
    <>
      <Header />
      <Home />
      <Footer />
      {/* <Home /> */}
    </>
  );
}

export default App;
